<?php
include '../includes/header.php';
include '../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

$donations = getDonationsByBloodGroup($conn);
$stock = mysqli_query($conn, "SELECT * FROM blood_stock ORDER BY blood_group");
$donors = getAllDonors($conn);
$daily_requests = getRequestSummary($conn, 'daily');
$monthly_requests = getRequestSummary($conn, 'monthly');
?>

<div class="row">
    <div class="col-md-10 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">System Reports</h2>

            <!-- Donations by Blood Group -->
            <h4>Donations by Blood Group</h4>
            <?php if (mysqli_num_rows($donations) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Blood Group</th>
                            <th>Number of Donations</th>
                            <th>Total Units</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($donations)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['blood_group']); ?></td>
                                <td><?php echo htmlspecialchars($row['count']); ?></td>
                                <td><?php echo htmlspecialchars($row['total_units']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No donations recorded.</p>
            <?php endif; ?>

            <!-- Blood Stock Summary -->
            <h4 class="mt-4">Blood Stock Summary</h4>
            <?php if (mysqli_num_rows($stock) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Blood Group</th>
                            <th>Units Available</th>
                            <th>Last Updated</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($stock)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['blood_group']); ?></td>
                                <td><?php echo htmlspecialchars($row['units']); ?></td>
                                <td><?php echo htmlspecialchars($row['updated_at']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No stock data available.</p>
            <?php endif; ?>

            <!-- List of All Donors -->
            <h4 class="mt-4">List of All Donors</h4>
            <?php if (mysqli_num_rows($donors) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Blood Group</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>Availability</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($donors)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['blood_group']); ?></td>
                                <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                <td><?php echo htmlspecialchars($row['address']); ?></td>
                                <td><?php echo htmlspecialchars($row['status']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No donors registered.</p>
            <?php endif; ?>

            <!-- Daily Request Summary -->
            <h4 class="mt-4">Daily Request Summary</h4>
            <?php if (mysqli_num_rows($daily_requests) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Number of Requests</th>
                            <th>Total Units Requested</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($daily_requests)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['date']); ?></td>
                                <td><?php echo htmlspecialchars($row['count']); ?></td>
                                <td><?php echo htmlspecialchars($row['total_units']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No requests recorded.</p>
            <?php endif; ?>

            <!-- Monthly Request Summary -->
            <h4 class="mt-4">Monthly Request Summary</h4>
            <?php if (mysqli_num_rows($monthly_requests) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Month</th>
                            <th>Number of Requests</th>
                            <th>Total Units Requested</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($monthly_requests)): ?>
                            <tr>
                                <td><?php echo date('Y-m', strtotime($row['date'])); ?></td>
                                <td><?php echo htmlspecialchars($row['count']); ?></td>
                                <td><?php echo htmlspecialchars($row['total_units']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No requests recorded.</p>
            <?php endif; ?>

            <p class="text-center mt-3"><a href="../dashboard/admin/index.php" class="btn btn-danger">Back to Dashboard</a></p>
            <p class="text-center mt-3"><a href="../notifications/notify.php" class="btn btn-outline-danger">Manage Notifications</a></p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>