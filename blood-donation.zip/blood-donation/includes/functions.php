<?php
include 'db.php';

function checkEligibility($conn, $donor_id) {
    $query = "SELECT date FROM donations WHERE donor_id = $donor_id ORDER BY date DESC LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) == 0) {
        return "Eligible (No previous donations)";
    }
    
    $last_donation = mysqli_fetch_assoc($result)['date'];
    $last_date = new DateTime($last_donation);
    $current_date = new DateTime();
    $interval = $last_date->diff($current_date);
    
    $months = $interval->m + ($interval->y * 12);
    if ($months >= 3) {
        return "Eligible (Last donation was more than 3 months ago)";
    } else {
        return "Not Eligible (Last donation was on $last_donation, wait until " . $last_date->modify('+3 months')->format('Y-m-d') . ")";
    }
}

function notifyDonors($conn, $blood_group, $request_id) {
    $query = "SELECT id, email FROM users WHERE role='donor' AND blood_group='$blood_group' AND status='available'";
    $result = mysqli_query($conn, $query);
    $notified = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $user_id = $row['id'];
        $email = $row['email'];
        $message = "Urgent: A blood request (#$request_id) needs $blood_group blood. Please contact the admin.";
        $query = "INSERT INTO notifications (user_id, message, type) VALUES ($user_id, '$message', 'request')";
        if (mysqli_query($conn, $query)) {
            $notified[] = $email;
        }
    }
    return $notified;
}

function updateStock($conn, $blood_group, $units, $action) {
    $operator = $action == 'add' ? '+' : '-';
    $query = "UPDATE blood_stock SET units = units $operator $units WHERE blood_group = '$blood_group'";
    return mysqli_query($conn, $query);
}

function checkLowStock($conn) {
    $query = "SELECT blood_group, units FROM blood_stock WHERE units < 5";
    $result = mysqli_query($conn, $query);
    $low_stock = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $low_stock[] = $row;
    }
    return $low_stock;
}

function searchDonors($conn, $blood_group, $location, $availability) {
    $query = "SELECT id, name, email, phone, blood_group, address, status 
              FROM users 
              WHERE role='donor'";
    
    if ($blood_group) {
        $blood_group = mysqli_real_escape_string($conn, $blood_group);
        $query .= " AND blood_group='$blood_group'";
    }
    if ($location) {
        $location = mysqli_real_escape_string($conn, $location);
        $query .= " AND address LIKE '%$location%'";
    }
    if ($availability) {
        $availability = mysqli_real_escape_string($conn, $availability);
        $query .= " AND status='$availability'";
    }
    
    $query .= " ORDER BY name";
    return mysqli_query($conn, $query);
}

function getDonationsByBloodGroup($conn) {
    $query = "SELECT blood_group, COUNT(*) as count, SUM(units) as total_units 
              FROM donations 
              GROUP BY blood_group";
    return mysqli_query($conn, $query);
}

function getAllDonors($conn) {
    $query = "SELECT name, email, blood_group, phone, address, status 
              FROM users 
              WHERE role='donor' 
              ORDER BY name";
    return mysqli_query($conn, $query);
}

function getRequestSummary($conn, $period) {
    $query = "SELECT DATE(requested_at) as date, COUNT(*) as count, SUM(units) as total_units 
              FROM blood_requests";
    
    if ($period == 'daily') {
        $query .= " GROUP BY DATE(requested_at)";
    } elseif ($period == 'monthly') {
        $query .= " GROUP BY YEAR(requested_at), MONTH(requested_at)";
    }
    
    $query .= " ORDER BY requested_at DESC";
    return mysqli_query($conn, $query);
}

function sendNotification($conn, $user_id, $message, $type) {
    $message = mysqli_real_escape_string($conn, $message);
    $query = "INSERT INTO notifications (user_id, message, type) VALUES ($user_id, '$message', '$type')";
    return mysqli_query($conn, $query);
}

function sendBroadcast($conn, $message, $role) {
    $query = "SELECT id FROM users WHERE role='$role'";
    $result = mysqli_query($conn, $query);
    $sent = 0;
    
    while ($row = mysqli_fetch_assoc($result)) {
        if (sendNotification($conn, $row['id'], $message, 'broadcast')) {
            $sent++;
        }
    }
    return $sent;
}

function checkEligibleDonors($conn) {
    $query = "SELECT u.id, u.email 
              FROM users u 
              LEFT JOIN donations d ON u.id = d.donor_id 
              WHERE u.role='donor' 
              GROUP BY u.id 
              HAVING MAX(d.date) IS NULL OR MAX(d.date) < DATE_SUB(CURDATE(), INTERVAL 3 MONTH)";
    $result = mysqli_query($conn, $query);
    $eligible = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $user_id = $row['id'];
        $message = "Reminder: You are eligible to donate blood. Please visit a donation center or respond to a request.";
        if (sendNotification($conn, $user_id, $message, 'reminder')) {
            $eligible[] = $row['email'];
        }
    }
    return $eligible;
}
?>