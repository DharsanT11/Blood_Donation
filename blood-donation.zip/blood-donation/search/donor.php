<?php
include '../includes/header.php';
include '../includes/db.php';
include '../includes/functions.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'recipient'])) {
    header('Location: ../login.php');
    exit();
}

if (!$conn) {
    die('<div class="alert alert-danger">Database connection failed: ' . mysqli_connect_error() . '</div>');
}

$blood_group = isset($_POST['blood_group']) ? $_POST['blood_group'] : '';
$location = isset($_POST['location']) ? $_POST['location'] : '';
$availability = isset($_POST['availability']) ? $_POST['availability'] : '';

$result = null;
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $result = searchDonors($conn, $blood_group, $location, $availability);
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Search Donors</h2>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Blood Group</label>
                    <select name="blood_group" class="form-select">
                        <option value="">All</option>
                        <option value="A+" <?php echo $blood_group == 'A+' ? 'selected' : ''; ?>>A+</option>
                        <option value="A-" <?php echo $blood_group == 'A-' ? 'selected' : ''; ?>>A-</option>
                        <option value="B+" <?php echo $blood_group == 'B+' ? 'selected' : ''; ?>>B+</option>
                        <option value="B-" <?php echo $blood_group == 'B-' ? 'selected' : ''; ?>>B-</option>
                        <option value="AB+" <?php echo $blood_group == 'AB+' ? 'selected' : ''; ?>>AB+</option>
                        <option value="AB-" <?php echo $blood_group == 'AB-' ? 'selected' : ''; ?>>AB-</option>
                        <option value="O+" <?php echo $blood_group == 'O+' ? 'selected' : ''; ?>>O+</option>
                        <option value="O-" <?php echo $blood_group == 'O-' ? 'selected' : ''; ?>>O-</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Location</label>
                    <input type="text" name="location" class="form-control" value="<?php echo htmlspecialchars($location); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Availability</label>
                    <select name="availability" class="form-select">
                        <option value="">All</option>
                        <option value="available" <?php echo $availability == 'available' ? 'selected' : ''; ?>>Available</option>
                        <option value="unavailable" <?php echo $availability == 'unavailable' ? 'selected' : ''; ?>>Unavailable</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-danger w-100">Search</button>
            </form>

            <?php if ($result): ?>
                <h4 class="mt-4">Search Results</h4>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Blood Group</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Availability</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($donor = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($donor['name']); ?></td>
                                    <td><?php echo htmlspecialchars($donor['blood_group']); ?></td>
                                    <td><?php echo htmlspecialchars($donor['email']); ?></td>
                                    <td><?php echo htmlspecialchars($donor['phone'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($donor['address'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($donor['status']); ?></td>
                                    <td><a href="contact.php?donor_id=<?php echo $donor['id']; ?>" class="btn btn-sm btn-outline-danger">View Details</a></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-center mt-3">No donors found matching your criteria.</p>
                <?php endif; ?>
            <?php endif; ?>
            
            <p class="text-center mt-3">
                <a href="/blood-donation/dashboard/<?php echo $_SESSION['role']; ?>/index.php" class="btn btn-danger">Back to Dashboard</a>
            </p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>