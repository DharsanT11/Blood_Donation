<?php
include '../includes/header.php';
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'recipient'])) {
    header('Location: ../login.php');
    exit();
}

if (!$conn) {
    die('<div class="alert alert-danger">Database connection failed: ' . mysqli_connect_error() . '</div>');
}

if (!isset($_GET['donor_id']) || !is_numeric($_GET['donor_id'])) {
    echo '<div class="alert alert-danger">Invalid donor ID.</div>';
    include '../includes/footer.php';
    exit();
}

$donor_id = (int)$_GET['donor_id'];
$query = "SELECT name, email, phone, blood_group, address, status 
          FROM users 
          WHERE id = $donor_id AND role = 'donor'";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    echo '<div class="alert alert-danger">Donor not found.</div>';
    include '../includes/footer.php';
    exit();
}

$donor = mysqli_fetch_assoc($result);
?>

<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Donor Contact Details</h2>
            <div class="mb-3">
                <strong>Name:</strong> <?php echo htmlspecialchars($donor['name']); ?>
            </div>
            <div class="mb-3">
                <strong>Email:</strong> <?php echo htmlspecialchars($donor['email']); ?>
            </div>
            <div class="mb-3">
                <strong>Phone:</strong> <?php echo htmlspecialchars($donor['phone'] ?? 'N/A'); ?>
            </div>
            <div class="mb-3">
                <strong>Blood Group:</strong> <?php echo htmlspecialchars($donor['blood_group']); ?>
            </div>
            <div class="mb-3">
                <strong>Address:</strong> <?php echo htmlspecialchars($donor['address'] ?? 'N/A'); ?>
            </div>
            <div class="mb-3">
                <strong>Availability:</strong> <?php echo htmlspecialchars($donor['status']); ?>
            </div>
            <p class="text-center mt-3">
                <a href="donor.php" class="btn btn-danger">Back to Search</a>
                <a href="/blood-donation/dashboard/<?php echo $_SESSION['role']; ?>/index.php" class="btn btn-outline-danger">Back to Dashboard</a>
            </p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>