<?php
include '../../includes/header.php';
include '../../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../../login.php');
    exit();
}

if (!$conn) {
    die('<div class="alert alert-danger">Database connection failed: ' . mysqli_connect_error() . '</div>');
}

$query = "SELECT * FROM contact_messages ORDER BY submitted_at DESC";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo '<div class="alert alert-danger">Query error: ' . mysqli_error($conn) . '</div>';
}
?>

<div class="row">
    <div class="col-md-10 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Contact Messages</h2>
            <?php if ($result && mysqli_num_rows($result) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Message</th>
                            <th>Submitted At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($message = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($message['name']); ?></td>
                                <td><?php echo htmlspecialchars($message['email']); ?></td>
                                <td><?php echo htmlspecialchars($message['message']); ?></td>
                                <td><?php echo htmlspecialchars($message['submitted_at']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-center">No messages received yet.</p>
            <?php endif; ?>
            <p class="text-center mt-3"><a href="index.php" class="btn btn-danger">Back to Dashboard</a></p>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>