<?php
include '../includes/header.php';
include '../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'recipient') {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $requester_id = $_SESSION['user_id'];
    $blood_group = $_POST['blood_group'];
    $units = (int)$_POST['units'];
    $reason = mysqli_real_escape_string($conn, $_POST['reason']);

    $query = "INSERT INTO blood_requests (requester_id, blood_group, units, reason) 
              VALUES ($requester_id, '$blood_group', $units, '$reason')";
    
    if (mysqli_query($conn, $query)) {
        $request_id = mysqli_insert_id($conn);
        $notified = notifyDonors($conn, $blood_group, $request_id);
        echo '<div class="alert alert-success">Request submitted successfully! Notified ' . count($notified) . ' donors. <a href="status.php">Check Status</a></div>';
    } else {
        echo '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card p-4">
            <h2 class="text-center mb-4">Request Blood</h2>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Blood Group</label>
                    <select name="blood_group" class="form-select" required>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Units Needed</label>
                    <input type="number" name="units" class="form-control" min="1" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Reason</label>
                    <textarea name="reason" class="form-control" required></textarea>
                </div>
                <button type="submit" class="btn btn-danger w-100">Submit Request</button>
            </form>
            <p class="text-center mt-3"><a href="status.php">View Request Status</a></p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>