<?php
include '../includes/header.php';
include '../includes/db.php'; // Ensure db.php is included to initialize $conn

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'recipient') {
    header('Location: ../login.php');
    exit();
}

// Verify database connection
if (!$conn) {
    die('<div class="alert alert-danger">Database connection failed: ' . mysqli_connect_error() . '</div>');
}

$requester_id = $_SESSION['user_id'];
$query = "SELECT * FROM blood_requests WHERE requester_id = $requester_id ORDER BY requested_at DESC";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo '<div class="alert alert-danger">Query error: ' . mysqli_error($conn) . '</div>';
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Request Status</h2>
            <?php if ($result && mysqli_num_rows($result) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Blood Group</th>
                            <th>Units</th>
                            <th>Reason</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($request = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($request['requested_at']); ?></td>
                                <td><?php echo htmlspecialchars($request['blood_group']); ?></td>
                                <td><?php echo htmlspecialchars($request['units']); ?></td>
                                <td><?php echo htmlspecialchars($request['reason']); ?></td>
                                <td><?php echo htmlspecialchars($request['status']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-center">No requests submitted yet.</p>
            <?php endif; ?>
            <p class="text-center mt-3"><a href="request.php" class="btn btn-danger">Submit New Request</a></p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>