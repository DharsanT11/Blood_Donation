<?php
include '../../includes/header.php';
include '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'donor') {
    header('Location: ../../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $blood_group = $_POST['blood_group'];
    $gender = $_POST['gender'];
    $age = (int)$_POST['age'];
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $status = $_POST['status'];

    $query = "UPDATE users SET 
              name='$name', 
              blood_group='$blood_group', 
              gender='$gender', 
              age=$age, 
              phone='$phone', 
              address='$address', 
              status='$status' 
              WHERE id=$user_id";
    
    if (mysqli_query($conn, $query)) {
        echo '<div class="alert alert-success">Profile updated successfully! <a href="index.php">Back to Dashboard</a></div>';
    } else {
        echo '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card p-4">
            <h2 class="text-center mb-4">Update Profile</h2>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Blood Group</label>
                    <select name="blood_group" class="form-select" required>
                        <option value="A+" <?php if ($user['blood_group'] == 'A+') echo 'selected'; ?>>A+</option>
                        <option value="A-" <?php if ($user['blood_group'] == 'A-') echo 'selected'; ?>>A-</option>
                        <option value="B+" <?php if ($user['blood_group'] == 'B+') echo 'selected'; ?>>B+</option>
                        <option value="B-" <?php if ($user['blood_group'] == 'B-') echo 'selected'; ?>>B-</option>
                        <option value="AB+" <?php if ($user['blood_group'] == 'AB+') echo 'selected'; ?>>AB+</option>
                        <option value="AB-" <?php if ($user['blood_group'] == 'AB-') echo 'selected'; ?>>AB-</option>
                        <option value="O+" <?php if ($user['blood_group'] == 'O+') echo 'selected'; ?>>O+</option>
                        <option value="O-" <?php if ($user['blood_group'] == 'O-') echo 'selected'; ?>>O-</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Gender</label>
                    <select name="gender" class="form-select" required>
                        <option value="Male" <?php if ($user['gender'] == 'Male') echo 'selected'; ?>>Male</option>
                        <option value="Female" <?php if ($user['gender'] == 'Female') echo 'selected'; ?>>Female</option>
                        <option value="Other" <?php if ($user['gender'] == 'Other') echo 'selected'; ?>>Other</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Age</label>
                    <input type="number" name="age" class="form-control" value="<?php echo htmlspecialchars($user['age']); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Phone</label>
                    <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Address</label>
                    <textarea name="address" class="form-control" required><?php echo htmlspecialchars($user['address']); ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Availability</label>
                    <select name="status" class="form-select" required>
                        <option value="available" <?php if ($user['status'] == 'available') echo 'selected'; ?>>Available</option>
                        <option value="not available" <?php if ($user['status'] == 'not available') echo 'selected'; ?>>Not Available</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-danger w-100">Update Profile</button>
            </form>
            <p class="text-center mt-3"><a href="index.php">Back to Dashboard</a></p>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>