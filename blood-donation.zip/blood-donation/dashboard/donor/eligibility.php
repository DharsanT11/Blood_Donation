<?php
include '../../includes/header.php';
include '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'donor') {
    header('Location: ../../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$eligibility = checkEligibility($conn, $user_id);
?>

<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Donation Eligibility</h2>
            <p class="text-center"><?php echo htmlspecialchars($eligibility); ?></p>
            <p class="text-center mt-3"><a href="index.php" class="btn btn-danger">Back to Dashboard</a></p>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>