<?php
include '../../includes/header.php';
include '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'donor') {
    header('Location: ../../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM donations WHERE donor_id = $user_id ORDER BY date DESC";
$result = mysqli_query($conn, $query);
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Donation History</h2>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Blood Group</th>
                            <th>Units</th>
                            <th>Location</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($donation = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($donation['date']); ?></td>
                                <td><?php echo htmlspecialchars($donation['blood_group']); ?></td>
                                <td><?php echo htmlspecialchars($donation['units']); ?></td>
                                <td><?php echo htmlspecialchars($donation['location']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-center">No donations recorded yet.</p>
            <?php endif; ?>
            <p class="text-center mt-3"><a href="index.php" class="btn btn-danger">Back to Dashboard</a></p>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>