<?php
include '../../includes/header.php';
include '../../includes/db.php'; // Include db.php to initialize $conn

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'donor') {
    header('Location: ../../login.php');
    exit();
}

// Verify database connection
if (!$conn) {
    die('<div class="alert alert-danger">Database connection failed: ' . mysqli_connect_error() . '</div>');
}

$user_id = $_SESSION['user_id'];
$query = "SELECT blood_group FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo '<div class="alert alert-danger">Query error: ' . mysqli_error($conn) . '</div>';
    exit();
}

$blood_group = mysqli_fetch_assoc($result)['blood_group'];

$query = "SELECT br.*, u.name, u.email FROM blood_requests br 
          JOIN users u ON br.requester_id = u.id 
          WHERE br.blood_group = '$blood_group' AND br.status = 'pending'";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo '<div class="alert alert-danger">Query error: ' . mysqli_error($conn) . '</div>';
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Blood Requests (<?php echo htmlspecialchars($blood_group); ?>)</h2>
            <?php if ($result && mysqli_num_rows($result) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Requester</th>
                            <th>Units</th>
                            <th>Reason</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($request = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($request['name']); ?> (<?php echo htmlspecialchars($request['email']); ?>)</td>
                                <td><?php echo htmlspecialchars($request['units']); ?></td>
                                <td><?php echo htmlspecialchars($request['reason']); ?></td>
                                <td><?php echo htmlspecialchars($request['requested_at']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-center">No pending requests for your blood group.</p>
            <?php endif; ?>
            <p class="text-center mt-3"><a href="index.php" class="btn btn-danger">Back to Dashboard</a></p>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>