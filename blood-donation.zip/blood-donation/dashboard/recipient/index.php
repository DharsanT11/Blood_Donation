<?php
include '../../includes/header.php';
include '../../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'recipient') {
    header('Location: ../../login.php');
    exit();
}

if (!$conn) {
    die('<div class="alert alert-danger">Database connection failed: ' . mysqli_connect_error() . '</div>');
}

$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo '<div class="alert alert-danger">Query error: ' . mysqli_error($conn) . '</div>';
    exit();
}

$user = mysqli_fetch_assoc($result);

// Fetch notifications
$notif_query = "SELECT message, type, created_at FROM notifications WHERE user_id = $user_id ORDER BY created_at DESC LIMIT 5";
$notif_result = mysqli_query($conn, $notif_query);
if (!$notif_result) {
    echo '<div class="alert alert-danger">Notification query error: ' . mysqli_error($conn) . '</div>';
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Recipient Dashboard</h2>
            <h4>Welcome, <?php echo htmlspecialchars($user['name']); ?>!</h4>
            
            <!-- Notifications Section -->
            <div class="mb-4">
                <h5>Notifications</h5>
                <?php if ($notif_result && mysqli_num_rows($notif_result) > 0): ?>
                    <ul class="list-group">
                        <?php while ($notif = mysqli_fetch_assoc($notif_result)): ?>
                            <li class="list-group-item">
                                <strong><?php echo htmlspecialchars($notif['type']); ?>:</strong>
                                <?php echo htmlspecialchars($notif['message']); ?>
                                <br><small><?php echo htmlspecialchars($notif['created_at']); ?></small>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                <?php else: ?>
                    <p>No notifications available.</p>
                <?php endif; ?>
            </div>
            
            <div class="row text-center">
                <div class="col-md-6 mb-3">
                    <a href="../../requests/request.php" class="btn btn-danger w-100">Request Blood</a>
                </div>
                <div class="col-md-6 mb-3">
                    <a href="../../requests/status.php" class="btn btn-danger w-100">View Request Status</a>
                </div>
                <div class="col-md-6 mb-3">
                    <a href="../../search/donor.php" class="btn btn-danger w-100">Search Donors</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>