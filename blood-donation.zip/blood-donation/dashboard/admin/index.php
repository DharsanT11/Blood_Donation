<?php
include '../../includes/header.php';
include '../../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../../login.php');
    exit();
}

if (!$conn) {
    die('<div class="alert alert-danger">Database connection failed: ' . mysqli_connect_error() . '</div>');
}
?>
<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Admin Dashboard</h2>
            <p>Welcome, Admin! Manage the system from here.</p>
            <div class="row text-center">
                <div class="col-md-4 mb-3">
                    <a href="requests.php" class="btn btn-danger w-100">Manage Blood Requests</a>
                </div>
                <div class="col-md-4 mb-3">
                    <a href="../../blood_stock/stock.php" class="btn btn-danger w-100">Manage Blood Stock</a>
                </div>
                <div class="col-md-4 mb-3">
                    <a href="../../search/donor.php" class="btn btn-danger w-100">Search Donors</a>
                </div>
                <div class="col-md-4 mb-3">
                    <a href="../../reports/reports.php" class="btn btn-danger w-100">View Reports</a>
                </div>
                <div class="col-md-4 mb-3">
                    <a href="../../notifications/notify.php" class="btn btn-danger w-100">Manage Notifications</a>
                </div>
                <div class="col-md-4 mb-3">
                    <a href="messages.php" class="btn btn-danger w-100">View Contact Messages</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include '../../includes/footer.php'; ?>