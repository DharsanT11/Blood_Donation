<?php
include '../../includes/header.php';
include '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $request_id = (int)$_POST['request_id'];
    $status = $_POST['status'];
    
    if ($status == 'fulfilled') {
        $query = "SELECT blood_group, units FROM blood_requests WHERE id = $request_id";
        $result = mysqli_query($conn, $query);
        $request = mysqli_fetch_assoc($result);
        updateStock($conn, $request['blood_group'], $request['units'], 'subtract');
    }

    $query = "UPDATE blood_requests SET status='$status' WHERE id=$request_id";
    if (mysqli_query($conn, $query)) {
        echo '<div class="alert alert-success">Request updated successfully!</div>';
    } else {
        echo '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
    }
}

$query = "SELECT br.*, u.name, u.email FROM blood_requests br 
          JOIN users u ON br.requester_id = u.id 
          ORDER BY br.requested_at DESC";
$result = mysqli_query($conn, $query);
?>

<div class="row">
    <div class="col-md-10 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Manage Blood Requests</h2>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Requester</th>
                            <th>Blood Group</th>
                            <th>Units</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($request = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($request['name']); ?> (<?php echo htmlspecialchars($request['email']); ?>)</td>
                                <td><?php echo htmlspecialchars($request['blood_group']); ?></td>
                                <td><?php echo htmlspecialchars($request['units']); ?></td>
                                <td><?php echo htmlspecialchars($request['reason']); ?></td>
                                <td><?php echo htmlspecialchars($request['status']); ?></td>
                                <td>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                        <select name="status" class="form-select d-inline w-auto">
                                            <option value="pending" <?php if ($request['status'] == 'pending') echo 'selected'; ?>>Pending</option>
                                            <option value="approved" <?php if ($request['status'] == 'approved') echo 'selected'; ?>>Approved</option>
                                            <option value="fulfilled" <?php if ($request['status'] == 'fulfilled') echo 'selected'; ?>>Fulfilled</option>
                                        </select>
                                        <button type="submit" class="btn btn-danger btn-sm">Update</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-center">No requests found.</p>
            <?php endif; ?>
            <p class="text-center mt-3"><a href="index.php" class="btn btn-danger">Back to Dashboard</a></p>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>