<?php
include '../../includes/header.php';
include '../../includes/db.php';
include '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../../login.php');
    exit();
}

if (!$conn) {
    die('<div class="alert alert-danger">Database connection failed: ' . mysqli_connect_error() . '</div>');
}

// Handle reply submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reply_message_id'])) {
    $message_id = (int)$_POST['reply_message_id'];
    $reply_content = mysqli_real_escape_string($conn, $_POST['reply_content']);
    $recipient_email = mysqli_real_escape_string($conn, $_POST['recipient_email']);

    // Find user_id by email
    $query = "SELECT id FROM users WHERE email = '$recipient_email'";
    $result = mysqli_query($conn, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        $user_id = $user['id'];

        // Insert reply into contact_replies table
        $query = "INSERT INTO contact_replies (message_id, reply_content) VALUES ($message_id, '$reply_content')";
        if (!mysqli_query($conn, $query)) {
            echo '<div class="alert alert-danger">Error saving reply: ' . mysqli_error($conn) . '</div>';
        } else {
            // Send notification to user
            $notification_message = "Admin reply to your contact message: $reply_content";
            if (sendNotification($conn, $user_id, $notification_message, 'contact_reply')) {
                echo '<div class="alert alert-success">Reply sent successfully to ' . htmlspecialchars($recipient_email) . '!</div>';
            } else {
                echo '<div class="alert alert-danger">Failed to send notification.</div>';
            }
        }
    } else {
        echo '<div class="alert alert-danger">User with email ' . htmlspecialchars($recipient_email) . ' not found.</div>';
    }
}

// Fetch contact messages
$query = "SELECT * FROM contact_messages ORDER BY submitted_at DESC";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo '<div class="alert alert-danger">Query error: ' . mysqli_error($conn) . '</div>';
}
?>

<div class="row">
    <div class="col-md-10 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Contact Messages</h2>
            <?php if ($result && mysqli_num_rows($result) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Message</th>
                            <th>Submitted At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($message = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($message['name']); ?></td>
                                <td><?php echo htmlspecialchars($message['email']); ?></td>
                                <td><?php echo htmlspecialchars($message['message']); ?></td>
                                <td><?php echo htmlspecialchars($message['submitted_at']); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#replyModal<?php echo $message['id']; ?>">Reply</button>
                                </td>
                            </tr>
                            <!-- Reply Modal -->
                            <div class="modal fade" id="replyModal<?php echo $message['id']; ?>" tabindex="-1" aria-labelledby="replyModalLabel<?php echo $message['id']; ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="replyModalLabel<?php echo $message['id']; ?>">Reply to <?php echo htmlspecialchars($message['name']); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form method="POST">
                                            <div class="modal-body">
                                                <input type="hidden" name="reply_message_id" value="<?php echo $message['id']; ?>">
                                                <input type="hidden" name="recipient_email" value="<?php echo htmlspecialchars($message['email']); ?>">
                                                <div class="mb-3">
                                                    <label class="form-label">Your Reply</label>
                                                    <textarea name="reply_content" class="form-control" rows="5" required></textarea>
                                                </div>
                                                <p><strong>Replying to:</strong> <?php echo htmlspecialchars($message['email']); ?></p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-danger">Send Reply</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-center">No messages received yet.</p>
            <?php endif; ?>
            <p class="text-center mt-3"><a href="index.php" class="btn btn-danger">Back to Dashboard</a></p>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>