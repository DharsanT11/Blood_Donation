<?php
include '../includes/header.php';
include '../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $blood_group = $_POST['blood_group'];
    $units = (int)$_POST['units'];
    $action = $_POST['action'];

    if (updateStock($conn, $blood_group, $units, $action)) {
        echo '<div class="alert alert-success">Stock updated successfully!</div>';
    } else {
        echo '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
    }
}

$query = "SELECT * FROM blood_stock ORDER BY blood_group";
$result = mysqli_query($conn, $query);
$low_stock = checkLowStock($conn);
?>

<div class="row">
    <div class="col-md-10 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Manage Blood Stock</h2>
            <?php if (!empty($low_stock)): ?>
                <div class="alert alert-warning">
                    <strong>Low Stock Alert:</strong>
                    <?php foreach ($low_stock as $stock): ?>
                        <?php echo htmlspecialchars($stock['blood_group']) . " (" . $stock['units'] . " units); "; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Blood Group</th>
                        <th>Units Available</th>
                        <th>Last Updated</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($stock = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($stock['blood_group']); ?></td>
                            <td><?php echo htmlspecialchars($stock['units']); ?></td>
                            <td><?php echo htmlspecialchars($stock['updated_at']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <h4 class="mt-4">Update Stock</h4>
            <form method="POST">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Blood Group</label>
                        <select name="blood_group" class="form-select" required>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Units</label>
                        <input type="number" name="units" class="form-control" min="1" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Action</label>
                        <select name="action" class="form-select" required>
                            <option value="add">Add Units</option>
                            <option value="subtract">Subtract Units</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-danger w-100">Update Stock</button>
            </form>
            <p class="text-center mt-3"><a href="../dashboard/admin/index.php" class="btn btn-danger">Back to Dashboard</a></p>
            <p class="text-center mt-3"><a href="../search/donor.php" class="btn btn-outline-danger">Search Donors</a></p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>