<?php
include 'includes/header.php';
include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    $query = "INSERT INTO contact_messages (name, email, message) VALUES ('$name', '$email', '$message')";
    if (mysqli_query($conn, $query)) {
        echo '<div class="alert alert-success">Message sent successfully! We will get back to you soon.</div>';
    } else {
        echo '<div class="alert alert-danger">Error: ' . mysqli_error($conn) . '</div>';
    }
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Contact Us</h2>
            
            <!-- Contact Details -->
            <div class="mb-4">
                <h4>Contact Information</h4>
                <p><strong>Email:</strong> support@blooddonation.org</p>
                <p><strong>Phone:</strong> +91-123-456-7890</p>
                <p><strong>Address:</strong> Blood Donation Center, 123 Health Street, Mumbai, India</p>
            </div>
            
            <!-- Contact Form -->
            <h4>Send Us a Message</h4>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Message</label>
                    <textarea name="message" class="form-control" rows="5" required></textarea>
                </div>
                <button type="submit" class="btn btn-danger w-100">Send Message</button>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>