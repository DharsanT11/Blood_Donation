<?php
include '../includes/header.php';
include '../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['broadcast'])) {
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    $role = $_POST['role'];
    $sent = sendBroadcast($conn, $message, $role);
    echo '<div class="alert alert-success">Broadcast sent to ' . $sent . ' users!</div>';
}

if (isset($_POST['check_eligible'])) {
    $eligible = checkEligibleDonors($conn);
    echo '<div class="alert alert-success">Reminders sent to ' . count($eligible) . ' eligible donors!</div>';

}

$query = "SELECT n.*, u.name, u.email 
          FROM notifications n 
          JOIN users u ON n.user_id = u.id 
          ORDER BY n.sent_at DESC";
$result = mysqli_query($conn, $query);
?>

<div class="row">
    <div class="col-md-10 mx-auto">
        <div class="card p-4">
            <h2 class="text-center mb-4">Manage Notifications</h2>

            <!-- Send Broadcast -->
            <h4>Send Broadcast Message</h4>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Recipient Role</label>
                    <select name="role" class="form-select" required>
                        <option value="donor">Donors</option>
                        <option value="recipient">Recipients</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Message</label>
                    <textarea name="message" class="form-control" required></textarea>
                </div>
                <button type="submit" name="broadcast" class="btn btn-danger w-100">Send Broadcast</button>
            </form>

            <!-- Check Eligible Donors -->
            <h4 class="mt-4">Check Eligible Donors</h4>
            <form method="POST">
                <button type="submit" name="check_eligible" class="btn btn-danger w-100">Send Eligibility Reminders</button>
            </form>

            <!-- Notification Log -->
            <h4 class="mt-4">Notification Log</h4>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Message</th>
                            <th>Type</th>
                            <th>Sent At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['name']); ?> (<?php echo htmlspecialchars($row['email']); ?>)</td>
                                <td><?php echo htmlspecialchars($row['message']); ?></td>
                                <td><?php echo htmlspecialchars($row['type']); ?></td>
                                <td><?php echo htmlspecialchars($row['sent_at']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No notifications sent yet.</p>
            <?php endif; ?>

            <p class="text-center mt-3"><a href="../dashboard/admin/index.php" class="btn btn-danger">Back to Dashboard</a></p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>