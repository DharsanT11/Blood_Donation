<?php include 'includes/header.php'; ?>
<div class="row justify-content-center">
    <div class="col-md-6 text-center">
        <h1 class="mb-4">Welcome to Blood Donation System</h1>
        <p class="lead">Connect donors and recipients to save lives.</p>
        <a href="register.php" class="btn btn-danger btn-lg m-2">Register Now</a>
        <a href="login.php" class="btn btn-outline-danger btn-lg m-2">Login</a>
    </div>
</div>
<?php include 'includes/footer.php'; ?>